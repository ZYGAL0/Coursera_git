#include "database.h"

void Database::Add(const Date &date, const std::string &event) {
    if (!event.empty()) {
        try {
            if (dbch.at(date).count(event) == 0) {
                db[date].push_back(event);
                dbch[date].insert(event);
            }
        } catch (...) {
            db[date].push_back(event);
            dbch[date].insert(event);
        }
    }
//    if (!event.empty()) {
//        try {
//            auto it = find(db.at(date).begin(), db.at(date).end(), event);
//            if (it == db.at(date).end()) {
//                db[date].push_back(event);
//            }
//        } catch (...) {
//            db[date].push_back(event);
//        }
//    }
}

void Database::Print(std::ostream &stream) const {
    for (const auto &i : db) {
        for (const auto &j : i.second) {
            stream << i.first << ' ' << j << std::endl;
        }
    }
}

std::pair<Date, std::string> Database::Last(const Date &date) const {
    if (db.empty()) {
        throw std::invalid_argument("");
    }
    if (date < db.begin()->first) {
        throw std::invalid_argument("");
    }
    auto res = db.upper_bound(date);
    return {prev(res)->first, prev(res)->second.back()};
}
